package com.example.calwidget

import android.app.job.JobParameters
import android.app.job.JobService

/** Периодическое обновление данных виджета через JobScheduler. */
class WidgetJobService : JobService() {

    override fun onStartJob(params: JobParameters?): Boolean {
        Thread {
            try {
                WidgetUpdater.refreshBlocking(this)
            } finally {
                jobFinished(params, false)
            }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = false
}
