package com.example.calwidget

/**
 * ID статичных слотов строк виджета (заголовок дня + строка события).
 * Файл и widget_layout.xml генерируются скриптом scripts/gen_widget_slots.py.
 */
internal object Slots {
    const val COUNT = 16
    val hdr = intArrayOf(R.id.hdr0, R.id.hdr1, R.id.hdr2, R.id.hdr3, R.id.hdr4, R.id.hdr5, R.id.hdr6, R.id.hdr7, R.id.hdr8, R.id.hdr9, R.id.hdr10, R.id.hdr11, R.id.hdr12, R.id.hdr13, R.id.hdr14, R.id.hdr15)
    val evt = intArrayOf(R.id.evt0, R.id.evt1, R.id.evt2, R.id.evt3, R.id.evt4, R.id.evt5, R.id.evt6, R.id.evt7, R.id.evt8, R.id.evt9, R.id.evt10, R.id.evt11, R.id.evt12, R.id.evt13, R.id.evt14, R.id.evt15)
    val dot = intArrayOf(R.id.dot0, R.id.dot1, R.id.dot2, R.id.dot3, R.id.dot4, R.id.dot5, R.id.dot6, R.id.dot7, R.id.dot8, R.id.dot9, R.id.dot10, R.id.dot11, R.id.dot12, R.id.dot13, R.id.dot14, R.id.dot15)
    val time = intArrayOf(R.id.time0, R.id.time1, R.id.time2, R.id.time3, R.id.time4, R.id.time5, R.id.time6, R.id.time7, R.id.time8, R.id.time9, R.id.time10, R.id.time11, R.id.time12, R.id.time13, R.id.time14, R.id.time15)
    val title = intArrayOf(R.id.title0, R.id.title1, R.id.title2, R.id.title3, R.id.title4, R.id.title5, R.id.title6, R.id.title7, R.id.title8, R.id.title9, R.id.title10, R.id.title11, R.id.title12, R.id.title13, R.id.title14, R.id.title15)
    val loc = intArrayOf(R.id.loc0, R.id.loc1, R.id.loc2, R.id.loc3, R.id.loc4, R.id.loc5, R.id.loc6, R.id.loc7, R.id.loc8, R.id.loc9, R.id.loc10, R.id.loc11, R.id.loc12, R.id.loc13, R.id.loc14, R.id.loc15)
}
