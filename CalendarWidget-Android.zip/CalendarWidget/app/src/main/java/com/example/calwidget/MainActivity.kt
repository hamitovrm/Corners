package com.example.calwidget

import android.Manifest
import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

/**
 * Экран настроек (и главный ярлык приложения): выбор календарей устройства —
 * показываются все, что синхронизированы с Google Календарём, включая
 * добавленные в нём подписки (праздники, спорт и т.п.). Интерфейс
 * собирается программно — разметка держит только контейнер.
 */
class MainActivity : Activity() {

    private lateinit var deviceList: LinearLayout
    private lateinit var spDays: Spinner
    private lateinit var spInterval: Spinner
    private lateinit var cbScrim: CheckBox
    private lateinit var cbLight: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        buildUi()
    }

    private fun buildUi() {
        val c = findViewById<LinearLayout>(R.id.container)
        c.removeAllViews()

        addDeviceSection(c)
        addOptionsSection(c)
        addButtons(c)
    }

    // ---------- Календари устройства ----------

    private fun addDeviceSection(c: LinearLayout) {
        c.addView(header(R.string.section_device))

        if (!DeviceCalendars.hasPermission(this)) {
            val t = caption(R.string.permission_needed)
            t.setTextColor(0xFFB3541E.toInt())
            t.setOnClickListener {
                @Suppress("DEPRECATION")
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 7)
            }
            c.addView(t)
            return
        }

        val cals = DeviceCalendars.listCalendars(this)
        if (cals.isEmpty()) {
            c.addView(caption(R.string.no_calendars_found))
            return
        }
        val chosen = Prefs.calendarsChosen(this)
        val sel = Prefs.selectedCalendars(this)
        deviceList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        for (cal in cals) {
            val label = if (cal.account.isNotEmpty() && cal.account != cal.name) {
                cal.name + " (" + cal.account + ")"
            } else {
                cal.name
            }
            val cb = CheckBox(this).apply {
                text = label
                textSize = 15f
                isChecked = if (chosen) cal.id.toString() in sel else true
                setOnClickListener {
                    // первый явный выбор: снять «все по умолчанию»
                    if (!Prefs.calendarsChosen(this@MainActivity)) {
                        for (i in 0 until deviceList.childCount) {
                            (deviceList.getChildAt(i) as CheckBox).isChecked = false
                        }
                        isChecked = true
                    }
                }
            }
            deviceList.addView(cb)
        }
        c.addView(deviceList)
        c.addView(caption(R.string.hint_subscribed))
    }

    // ---------- Параметры ----------

    private fun addOptionsSection(c: LinearLayout) {
        c.addView(header(R.string.section_options))

        val dayLabels = listOf(
            getString(R.string.day1), getString(R.string.day3),
            getString(R.string.day7), getString(R.string.day14), getString(R.string.day30)
        )
        val dayValues = intArrayOf(1, 3, 7, 14, 30)
        spDays = spinner(dayLabels, dayValues.indexOfFirst { it == Prefs.daysAhead(this) })

        val intLabels = listOf(
            getString(R.string.min15), getString(R.string.min30),
            getString(R.string.hour1), getString(R.string.hour3)
        )
        val intValues = intArrayOf(15, 30, 60, 180)
        spInterval = spinner(intLabels, intValues.indexOfFirst { it == Prefs.intervalMinutes(this) })

        cbScrim = CheckBox(this).apply {
            text = getString(R.string.dark_scrim)
            isChecked = Prefs.scrim(this@MainActivity)
        }
        cbLight = CheckBox(this).apply {
            text = getString(R.string.light_text)
            isChecked = Prefs.lightText(this@MainActivity)
        }

        c.addView(rowWithOptions(getString(R.string.days_ahead), spDays))
        c.addView(rowWithOptions(getString(R.string.refresh_interval), spInterval))
        c.addView(cbScrim)
        c.addView(cbLight)
    }

    private fun rowWithOptions(label: String, sp: Spinner): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(sp)
        return row
    }

    private fun spinner(items: List<String>, selected: Int): Spinner {
        val sp = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        if (selected >= 0) sp.setSelection(selected)
        sp.layoutParams = ViewGroup.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT)
        return sp
    }

    // ---------- Кнопки ----------

    private fun addButtons(c: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(16), 0, dp(8))
        }
        val btnRefresh = Button(this).apply {
            text = getString(R.string.refresh_now)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            setOnClickListener {
                WidgetUpdater.refreshNow(this@MainActivity)
                Toast.makeText(this@MainActivity, R.string.saved, Toast.LENGTH_SHORT).show()
            }
        }
        val btnSave = Button(this).apply {
            text = getString(R.string.save)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { save() }
        }
        row.addView(btnRefresh)
        row.addView(btnSave)
        c.addView(row)
    }

    private fun save() {
        val ids = HashSet<String>()
        if (::deviceList.isInitialized) {
            val cals = DeviceCalendars.listCalendars(this)
            for (i in 0 until deviceList.childCount) {
                val cb = deviceList.getChildAt(i) as CheckBox
                if (cb.isChecked && i < cals.size) ids.add(cals[i].id.toString())
            }
        }
        Prefs.saveSelectedCalendars(this, ids)

        val dayValues = intArrayOf(1, 3, 7, 14, 30)
        val intValues = intArrayOf(15, 30, 60, 180)
        Prefs.saveOptions(
            this,
            dayValues[spDays.selectedItemPosition.coerceAtLeast(0)],
            intValues[spInterval.selectedItemPosition.coerceAtLeast(0)],
            cbScrim.isChecked,
            cbLight.isChecked
        )
        Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
        WidgetUpdater.refreshNow(this)
        finish()
    }

    // ---------- Разрешение ----------

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            buildUi()
            // Разрешение только что выдано — сразу наполнить виджет
            WidgetUpdater.refreshNow(this)
        }
    }

    // ---------- Мелкие помощники разметки ----------

    private fun header(res: Int): TextView = TextView(this).apply {
        text = getString(res)
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(20), 0, dp(8))
    }

    private fun caption(res: Int): TextView = TextView(this).apply {
        text = getString(res)
        textSize = 14f
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
