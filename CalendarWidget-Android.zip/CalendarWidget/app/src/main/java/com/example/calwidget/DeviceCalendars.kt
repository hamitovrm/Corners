package com.example.calwidget

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract

/**
 * Календари устройства: аккаунты, синхронизированные системой
 * (в их числе Google Календарь — виджет читает их через Calendar Provider).
 */
object DeviceCalendars {

    class CalInfo(val id: Long, val name: String, val account: String, val color: Int)

    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    /** Список календарей, видимых устройству. */
    fun listCalendars(context: Context): List<CalInfo> {
        if (!hasPermission(context)) return emptyList()
        val proj = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.CALENDAR_COLOR
        )
        val out = ArrayList<CalInfo>()
        try {
            context.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI, proj, null, null, null
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
                val iName = c.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
                val iAcc = c.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_NAME)
                val iColor = c.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_COLOR)
                while (c.moveToNext()) {
                    out.add(
                        CalInfo(
                            c.getLong(iId),
                            c.getString(iName) ?: "",
                            c.getString(iAcc) ?: "",
                            c.getInt(iColor)
                        )
                    )
                }
            }
        } catch (ignored: Exception) {
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /**
     * События выбранных календарей в окне времени. Повторяющиеся события
     * уже развёрнуты системой (запрос к «Instances»).
     */
    fun queryEvents(
        context: Context,
        calendarIds: Set<Long>,
        windowStart: Long,
        windowEnd: Long
    ): List<EventData> {
        if (!hasPermission(context)) return emptyList()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, windowStart)
        ContentUris.appendId(b, windowEnd)
        val proj = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.CALENDAR_COLOR,
            CalendarContract.Instances.CALENDAR_ID
        )
        val out = ArrayList<EventData>()
        try {
            context.contentResolver.query(
                b.build(), proj, null, null, CalendarContract.Instances.BEGIN + " ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
                val iTitle = c.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
                val iBegin = c.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
                val iEnd = c.getColumnIndexOrThrow(CalendarContract.Instances.END)
                val iAllDay = c.getColumnIndexOrThrow(CalendarContract.Instances.ALL_DAY)
                val iLoc = c.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_LOCATION)
                val iColor = c.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_COLOR)
                val iCal = c.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_ID)
                while (c.moveToNext()) {
                    if (calendarIds.isNotEmpty() && c.getLong(iCal) !in calendarIds) continue
                    val begin = c.getLong(iBegin)
                    val title = c.getString(iTitle) ?: "(без названия)"
                    out.add(
                        EventData(
                            key = "d" + c.getLong(iId) + "_" + begin,
                            title = title,
                            start = begin,
                            end = c.getLong(iEnd),
                            allDay = c.getInt(iAllDay) != 0,
                            location = c.getString(iLoc),
                            color = c.getInt(iColor),
                            eventId = c.getLong(iId)
                        )
                    )
                }
            }
        } catch (ignored: SecurityException) {
        } catch (ignored: Exception) {
        }
        return out
    }
}
