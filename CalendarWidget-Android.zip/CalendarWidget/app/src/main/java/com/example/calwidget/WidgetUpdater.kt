package com.example.calwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.CalendarContract
import android.text.format.DateUtils
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Обновление виджета: чтение календарей устройства (Google Календарь и все
 * календари, добавленные в нём, синхронизируются системой автоматически),
 * группировка по дням, отрисовка статичных строк RemoteViews и планирование
 * периодических обновлений.
 *
 * Статичные слоты вместо ListView: список не прокручивается, зато виджет
 * добавляется на любом лаунчере (POCO/MIUI/HyperOS) и не требует службы
 * RemoteViewsService. Все PendingIntent — явные и IMMUTABLE (требование
 * Android 14+/15+/16).
 */
object WidgetUpdater {

    const val ACTION_REFRESH = "com.example.calwidget.REFRESH"
    const val ACTION_OPEN_TODAY = "com.example.calwidget.OPEN_TODAY"
    const val ACTION_CREATE_EVENT = "com.example.calwidget.CREATE_EVENT"
    private const val JOB_ID = 42
    private val executor = Executors.newSingleThreadExecutor()

    /** Полное обновление (фоновый поток). */
    fun refreshNow(context: Context) {
        executor.execute { doRefresh(context) }
    }

    /** Синхронное обновление — вызывать из уже фонового потока. */
    fun refreshBlocking(context: Context) = doRefresh(context)

    private fun doRefresh(context: Context) {
        val daysAhead = Prefs.daysAhead(context)
        val now = System.currentTimeMillis()
        val windowStart = now - DateUtils.DAY_IN_MILLIS   // назад — ради идущих событий
        val windowEnd = now + daysAhead * DateUtils.DAY_IN_MILLIS

        // Календари устройства (включая Google и его подписки)
        val ids = Prefs.selectedCalendars(context).mapNotNull { it.toLongOrNull() }.toSet()
        val events = DeviceCalendars.queryEvents(context, ids, windowStart, windowEnd)

        val rows = buildRows(context, events, Slots.COUNT)
        try {
            RowStore.save(context, rows)
        } catch (ignored: Exception) {
        }
        try {
            render(context)
        } catch (ignored: Exception) {
        }
        try {
            schedule(context)
        } catch (ignored: Exception) {
        }
    }

    /** Отрисовка из кэша — мгновенно, без запросов (onUpdate, смена дня и т.п.). */
    fun render(context: Context) {
        val mgr = AppWidgetManager.getInstance(context) ?: return
        val ids = mgr.getAppWidgetIds(ComponentName(context, EventWidgetProvider::class.java))
        if (ids.isEmpty()) return
        val light = Prefs.lightText(context)
        val mainColor = if (light) 0xFFFFFFFF.toInt() else 0xFF202124.toInt()
        val dimColor = if (light) 0xCCFFFFFF.toInt() else 0xB3202124.toInt()
        val rows = RowStore.load(context)
        val eventCount = rows.count { it is Row.Event }

        for (id in ids) {
            val rv = RemoteViews(context.packageName, R.layout.widget_layout)
            if (Prefs.scrim(context)) {
                rv.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.scrim_dark)
            } else {
                rv.setInt(R.id.widget_root, "setBackgroundColor", 0)
            }

            // Заголовок: дата и время «живьём» (TextClock) + кнопки
            rv.setTextColor(R.id.tv_clock, mainColor)
            rv.setViewVisibility(R.id.empty, if (eventCount == 0) View.VISIBLE else View.GONE)
            rv.setTextColor(R.id.empty, dimColor)
            rv.setOnClickPendingIntent(R.id.tv_clock, clockPendingIntent(context))
            rv.setOnClickPendingIntent(R.id.btn_add, addPendingIntent(context))
            rv.setOnClickPendingIntent(R.id.btn_refresh, refreshPendingIntent(context))
            rv.setOnClickPendingIntent(R.id.btn_settings, settingsPendingIntent(context))

            // Статичные слоты строк
            for (i in 0 until Slots.COUNT) {
                when (val row = rows.getOrNull(i)) {
                    is Row.Header -> {
                        rv.setViewVisibility(Slots.evt[i], View.GONE)
                        rv.setViewVisibility(Slots.hdr[i], View.VISIBLE)
                        rv.setTextViewText(Slots.hdr[i], row.label)
                        rv.setTextColor(Slots.hdr[i], dimColor)
                    }
                    is Row.Event -> {
                        val e = row.data
                        rv.setViewVisibility(Slots.hdr[i], View.GONE)
                        rv.setViewVisibility(Slots.evt[i], View.VISIBLE)
                        rv.setTextViewText(Slots.time[i], timeText(context, e))
                        rv.setTextViewText(Slots.title[i], e.title)
                        val loc = e.location ?: ""
                        rv.setTextViewText(Slots.loc[i], loc)
                        rv.setViewVisibility(Slots.loc[i], if (loc.isEmpty()) View.GONE else View.VISIBLE)
                        rv.setTextColor(Slots.time[i], dimColor)
                        rv.setTextColor(Slots.title[i], mainColor)
                        rv.setTextColor(Slots.loc[i], dimColor)
                        rv.setInt(Slots.dot[i], "setBackgroundColor", e.color)
                        rv.setOnClickPendingIntent(Slots.evt[i], eventPendingIntent(context, i, e))
                    }
                    null -> {
                        rv.setViewVisibility(Slots.hdr[i], View.GONE)
                        rv.setViewVisibility(Slots.evt[i], View.GONE)
                    }
                }
            }
            mgr.updateAppWidget(id, rv)
        }
    }

    // ---------- Группировка строк ----------

    private fun buildRows(context: Context, events: List<EventData>, limit: Int): List<Row> {
        // События, начавшиеся недавно, ещё показываем (не «пропадают» сразу в начале)
        val cut = System.currentTimeMillis() - 30 * 60 * 1000L
        val sorted = events.filter { it.end > cut }
            .sortedWith(compareBy({ it.start }, { it.title.lowercase() }))
        val rows = ArrayList<Row>()
        var lastDay = Long.MIN_VALUE
        for (e in sorted) {
            val day = dayStart(e.start)
            if (day != lastDay) {
                if (rows.size + 1 >= limit) break
                rows.add(Row.Header(dayLabel(context, e.start, e.allDay)))
                lastDay = day
            }
            rows.add(Row.Event(e))
            if (rows.size >= limit) break
        }
        // не оставлять «висячий» заголовок дня без событий
        while (rows.isNotEmpty() && rows.last() is Row.Header) rows.removeAt(rows.size - 1)
        return rows
    }

    private fun dayStart(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun dayLabel(context: Context, start: Long, allDay: Boolean): String {
        val flags = DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_WEEKDAY or
            DateUtils.FORMAT_ABBREV_MONTH or
            (if (allDay) DateUtils.FORMAT_UTC else 0)
        val base = DateUtils.formatDateTime(context, start, flags)
        val tomorrow = dayStart(start) == dayStart(System.currentTimeMillis()) + DateUtils.DAY_IN_MILLIS
        return when {
            DateUtils.isToday(start) -> context.getString(R.string.today) + ", " + base
            tomorrow -> context.getString(R.string.tomorrow) + ", " + base
            else -> base
        }
    }

    private fun timeText(context: Context, e: EventData): String {
        if (e.allDay) {
            val days = ((e.end - e.start) / (24L * 3600 * 1000)).toInt()
            if (days <= 1) return context.getString(R.string.allday)
            val f = SimpleDateFormat("d MMM", Locale.getDefault())
            return f.format(Date(e.start)) + " – " + f.format(Date(e.end - 1))
        }
        val f = SimpleDateFormat("HH:mm", Locale.getDefault())
        val cal = Calendar.getInstance()
        cal.timeInMillis = e.start
        val sd = cal.get(Calendar.DAY_OF_MONTH)
        cal.timeInMillis = e.end
        val end = if (cal.get(Calendar.DAY_OF_MONTH) == sd) {
            "–" + f.format(Date(e.end))
        } else {
            " – " + SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(e.end))
        }
        return f.format(Date(e.start)) + end
    }

    // ---------- Планирование обновлений ----------

    /** JobScheduler (основной механизм) + неточный будильник (страховка). */
    fun schedule(context: Context) {
        val intervalMs = Prefs.intervalMinutes(context).coerceAtLeast(15) * 60_000L

        val js = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val job = JobInfo.Builder(JOB_ID, ComponentName(context, WidgetJobService::class.java))
            .setPeriodic(intervalMs)
            .setPersisted(true)
            .build()
        try {
            js.schedule(job)
        } catch (ignored: Exception) {
        }

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = refreshPendingIntent(context)
        am.cancel(pi)
        am.setInexactRepeating(
            AlarmManager.ELAPSED_REALTIME,
            SystemClock.elapsedRealtime() + intervalMs,
            intervalMs,
            pi
        )
    }

    // ---------- PendingIntent (все явные + IMMUTABLE — Android 12…16) ----------

    fun refreshPendingIntent(context: Context): PendingIntent {
        val i = Intent(context, EventWidgetProvider::class.java).setAction(ACTION_REFRESH)
        return PendingIntent.getBroadcast(
            context, 1, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun settingsPendingIntent(context: Context): PendingIntent {
        val i = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            context, 2, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Дата/время в заголовке → Google Календарь на сегодня. */
    private fun clockPendingIntent(context: Context): PendingIntent {
        val i = Intent(context, EventClickActivity::class.java)
            .setAction(ACTION_OPEN_TODAY)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            context, 4, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Кнопка «+» → создание события в Google Календаре. */
    private fun addPendingIntent(context: Context): PendingIntent {
        val i = Intent(context, EventClickActivity::class.java)
            .setAction(ACTION_CREATE_EVENT)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            context, 5, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Строка события → карточка события в Google Календаре. */
    private fun eventPendingIntent(context: Context, slot: Int, e: EventData): PendingIntent {
        val i = Intent(context, EventClickActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.data = if (e.eventId != null) {
            ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, e.eventId!!)
        } else {
            Uri.parse("content://com.android.calendar/time/" + e.start)
        }
        i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, e.start)
        return PendingIntent.getActivity(
            context, 100 + slot, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
