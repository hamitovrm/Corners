package com.example.calwidget

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract

/**
 * Промежуточная (trampoline) активность для нажатий в виджете.
 *
 * Все PendingIntent виджета — ЯВНЫЕ (на эту активность) и IMMUTABLE:
 * это требование Android 14+ (targetSdk 34+), на Android 15/16 неявные
 * mutable-варианты запрещены системой. Здесь мы открываем стандартный
 * Google Календарь: карточку события, экран создания события или
 * календарь на сегодня.
 */
class EventClickActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent?.action) {
            WidgetUpdater.ACTION_OPEN_TODAY -> openToday()
            WidgetUpdater.ACTION_CREATE_EVENT -> createEvent()
            else -> openEvent(intent)
        }
        finish()
    }

    /** Заголовок (дата/время) → календарь на сегодня. */
    private fun openToday() {
        val uri = Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis())
        if (!tryStart(viewIntent(uri))) {
            tryStart(mainCalendarIntent())
        }
    }

    /** Кнопка «+» → создание события (следующий час по умолчанию). */
    private fun createEvent() {
        val start = System.currentTimeMillis()
        val i = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + 60 * 60 * 1000L)
        if (!tryStart(Intent(i).setPackage(GOOGLE_CALENDAR))) {
            if (!tryStart(i)) tryStart(mainCalendarIntent())
        }
    }

    /** Строка события → карточка события в календаре. */
    private fun openEvent(src: Intent?) {
        val data: Uri? = src?.data
        if (data != null) {
            val view = viewIntent(data)
            if (src.extras != null) view.putExtras(src.extras!!)
            // Приоритет — стандартный Google Календарь
            if (tryStart(Intent(view).setPackage(GOOGLE_CALENDAR))) return
            // Иначе — любое приложение, умеющее показать это событие/день
            if (tryStart(view)) return
        }
        // Крайний случай — просто открыть приложение календаря
        tryStart(mainCalendarIntent())
    }

    private fun viewIntent(uri: Uri): Intent =
        Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun mainCalendarIntent(): Intent =
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)

    private fun tryStart(i: Intent): Boolean =
        try {
            startActivity(i)
            true
        } catch (ignored: Exception) {
            false
        }

    private companion object {
        const val GOOGLE_CALENDAR = "com.google.android.calendar"
    }
}
