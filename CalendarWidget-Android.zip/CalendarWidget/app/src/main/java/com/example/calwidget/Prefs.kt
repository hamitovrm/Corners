package com.example.calwidget

import android.content.Context

/**
 * Все настройки виджета в SharedPreferences:
 * выбранные календари устройства и параметры отображения.
 */
object Prefs {
    private const val FILE = "widget"
    private const val K_CALENDARS = "calendars"         // выбранные id календарей устройства
    private const val K_CALENDARS_SET = "calendars_set" // пользователь уже делал выбор
    private const val K_DAYS = "days_ahead"
    private const val K_INTERVAL = "interval_min"
    private const val K_SCRIM = "dark_scrim"
    private const val K_LIGHT = "light_text"

    private fun sp(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun selectedCalendars(context: Context): Set<String> =
        sp(context).getStringSet(K_CALENDARS, emptySet()) ?: emptySet()

    fun calendarsChosen(context: Context): Boolean = sp(context).getBoolean(K_CALENDARS_SET, false)

    fun saveSelectedCalendars(context: Context, ids: Set<String>) {
        sp(context).edit().putStringSet(K_CALENDARS, ids).putBoolean(K_CALENDARS_SET, true).apply()
    }

    fun daysAhead(context: Context): Int = sp(context).getInt(K_DAYS, 7)

    fun intervalMinutes(context: Context): Int = sp(context).getInt(K_INTERVAL, 30)

    fun scrim(context: Context): Boolean = sp(context).getBoolean(K_SCRIM, false)

    fun lightText(context: Context): Boolean = sp(context).getBoolean(K_LIGHT, true)

    fun saveOptions(context: Context, days: Int, intervalMin: Int, scrim: Boolean, light: Boolean) {
        sp(context).edit()
            .putInt(K_DAYS, days)
            .putInt(K_INTERVAL, intervalMin)
            .putBoolean(K_SCRIM, scrim)
            .putBoolean(K_LIGHT, light)
            .apply()
    }
}
