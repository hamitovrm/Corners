package com.example.calwidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Одно событие (из системного календаря или внешнего ICS). */
data class EventData(
    val key: String,        // уникальный ключ строки
    val title: String,
    val start: Long,        // millis UTC
    val end: Long,
    val allDay: Boolean,
    val location: String?,
    val color: Int,         // цвет календаря-источника
    val eventId: Long?      // id в системном календаре; null — для внешних ICS
)

/** Строка виджета: заголовок дня или событие. */
sealed class Row {
    class Header(val label: String) : Row()
    class Event(val data: EventData) : Row()
}

/**
 * Строки виджета сериализуются в JSON-файл: поставщик списка читает его
 * без обращения к сети и календарю (ListView обновляется мгновенно).
 */
object RowStore {

    private fun file(context: Context) = File(context.filesDir, "widget_rows.json")

    fun save(context: Context, rows: List<Row>) {
        val arr = JSONArray()
        for (r in rows) {
            when (r) {
                is Row.Header -> arr.put(
                    JSONObject().put("t", "h").put("l", r.label)
                )
                is Row.Event -> {
                    val e = r.data
                    arr.put(
                        JSONObject()
                            .put("t", "e")
                            .put("k", e.key)
                            .put("ti", e.title)
                            .put("s", e.start)
                            .put("e", e.end)
                            .put("a", e.allDay)
                            .put("loc", e.location ?: "")
                            .put("c", e.color)
                            .put("id", e.eventId ?: -1L)
                    )
                }
            }
        }
        try {
            val tmp = File(context.filesDir, "widget_rows.json.tmp")
            tmp.writeText(arr.toString())
            val dst = file(context)
            dst.delete()
            tmp.renameTo(dst)
        } catch (ignored: Exception) {
        }
    }

    fun load(context: Context): List<Row> {
        val out = ArrayList<Row>()
        try {
            val f = file(context)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getString("t") == "h") {
                    out.add(Row.Header(o.getString("l")))
                } else {
                    out.add(
                        Row.Event(
                            EventData(
                                key = o.getString("k"),
                                title = o.getString("ti"),
                                start = o.getLong("s"),
                                end = o.getLong("e"),
                                allDay = o.getBoolean("a"),
                                location = o.optString("loc").ifEmpty { null },
                                color = o.getInt("c"),
                                eventId = o.getLong("id").takeIf { it >= 0 }
                            )
                        )
                    )
                }
            }
        } catch (ignored: Exception) {
        }
        return out
    }
}
