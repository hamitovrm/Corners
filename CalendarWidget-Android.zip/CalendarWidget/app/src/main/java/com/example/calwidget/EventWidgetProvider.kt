package com.example.calwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

/**
 * Виджет «Прозрачный календарь».
 * Рисуется из кэша строк мгновенно (статичные слоты); данные обновляются
 * по расписанию (JobScheduler + будильник), по кнопке со стрелкой и при
 * смене даты/времени. Все вызовы обёрнуты в try/catch — провайдер не
 * имеет права упасть во время добавления виджета на экран.
 */
class EventWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        safe { WidgetUpdater.render(context) }
        safe { WidgetUpdater.schedule(context) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle?
    ) {
        safe { WidgetUpdater.render(context) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            WidgetUpdater.ACTION_REFRESH -> {
                // Кнопка на виджете: полное обновление
                val pending = goAsync()
                Thread {
                    try {
                        safe { WidgetUpdater.refreshBlocking(context) }
                    } finally {
                        pending.finish()
                    }
                }.start()
            }
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> {
                // После перезагрузки или смены времени достаточно перерисовать из кэша
                val pending = goAsync()
                Thread {
                    try {
                        safe { WidgetUpdater.render(context) }
                        safe { WidgetUpdater.schedule(context) }
                    } finally {
                        pending.finish()
                    }
                }.start()
            }
        }
    }

    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (ignored: Throwable) {
        }
    }
}
