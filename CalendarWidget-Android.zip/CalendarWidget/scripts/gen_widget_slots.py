#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация widget_layout.xml со статичными слотами строк виджета
и Slots.kt с массивами id слотов. Статичные строки вместо ListView —
максимальная совместимость с лаунчерами (POCO/MIUI/HyperOS)."""

SLOTS = 16
LAYOUT = "/home/z/my-project/CalendarWidget/app/src/main/res/layout/widget_layout.xml"
SLOTS_KT = "/home/z/my-project/CalendarWidget/app/src/main/java/com/example/calwidget/Slots.kt"

HDR = '''        <TextView
            android:id="@+id/hdr{i}"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:paddingStart="2dp"
            android:paddingTop="8dp"
            android:paddingBottom="2dp"
            android:textSize="12sp"
            android:textStyle="bold"
            android:textColor="@color/widget_text_light_dim"
            android:shadowColor="#B3000000"
            android:shadowRadius="3"
            android:shadowDy="1"
            android:singleLine="true"
            android:ellipsize="end"
            android:visibility="gone" />
'''

EVT = '''        <LinearLayout
            android:id="@+id/evt{i}"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical"
            android:paddingStart="2dp"
            android:paddingEnd="4dp"
            android:paddingTop="3dp"
            android:paddingBottom="3dp"
            android:visibility="gone">

            <View
                android:id="@+id/dot{i}"
                android:layout_width="4dp"
                android:layout_height="match_parent"
                android:minHeight="28dp" />

            <LinearLayout
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:layout_marginStart="8dp"
                android:orientation="vertical">

                <TextView
                    android:id="@+id/time{i}"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:textSize="11sp"
                    android:textColor="@color/widget_text_light_dim"
                    android:shadowColor="#B3000000"
                    android:shadowRadius="3"
                    android:shadowDy="1"
                    android:singleLine="true" />

                <TextView
                    android:id="@+id/title{i}"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:textSize="14sp"
                    android:textColor="@color/widget_text_light"
                    android:shadowColor="#B3000000"
                    android:shadowRadius="3"
                    android:shadowDy="1"
                    android:singleLine="true"
                    android:ellipsize="end" />

                <TextView
                    android:id="@+id/loc{i}"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:textSize="11sp"
                    android:textColor="@color/widget_text_light_dim"
                    android:shadowColor="#B3000000"
                    android:shadowRadius="3"
                    android:shadowDy="1"
                    android:singleLine="true"
                    android:ellipsize="end" />
            </LinearLayout>
        </LinearLayout>
'''

HEADER = '''<?xml version="1.0" encoding="utf-8"?>
<!-- Прозрачный виджет: статичные строки (без ListView — надёжнее на MIUI/HyperOS).
     Заголовок: живые дата и время (TextClock) + кнопки «+», обновить, настройки. -->
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="8dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical">

        <TextClock
            android:id="@+id/tv_clock"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:format24Hour="EEE, d MMM HH:mm"
            android:format12Hour="EEE, d MMM h:mm a"
            android:textSize="14sp"
            android:textStyle="bold"
            android:textColor="@color/widget_text_light"
            android:shadowColor="#B3000000"
            android:shadowRadius="3"
            android:shadowDy="1"
            android:singleLine="true"
            android:ellipsize="end"
            android:contentDescription="@string/cd_clock" />

        <ImageView
            android:id="@+id/btn_add"
            android:layout_width="30dp"
            android:layout_height="30dp"
            android:padding="5dp"
            android:background="@drawable/btn_circle"
            android:src="@drawable/ic_add"
            android:contentDescription="@string/cd_add_event" />

        <ImageView
            android:id="@+id/btn_refresh"
            android:layout_width="30dp"
            android:layout_height="30dp"
            android:layout_marginStart="6dp"
            android:padding="5dp"
            android:background="@drawable/btn_circle"
            android:src="@drawable/ic_refresh"
            android:contentDescription="@string/refresh_now" />

        <ImageView
            android:id="@+id/btn_settings"
            android:layout_width="30dp"
            android:layout_height="30dp"
            android:layout_marginStart="6dp"
            android:padding="5dp"
            android:background="@drawable/btn_circle"
            android:src="@drawable/ic_settings"
            android:contentDescription="@string/settings_title" />
    </LinearLayout>

    <FrameLayout
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:layout_marginTop="4dp">

        <LinearLayout
            android:id="@+id/rows"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical">

'''

EMPTY = '''
        </LinearLayout>

        <TextView
            android:id="@+id/empty"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_gravity="center"
            android:gravity="center"
            android:textSize="13sp"
            android:textColor="@color/widget_text_light_dim"
            android:shadowColor="#B3000000"
            android:shadowRadius="3"
            android:shadowDy="1"
            android:text="@string/widget_empty" />
    </FrameLayout>
</LinearLayout>
'''

body = ""
for i in range(SLOTS):
    body += HDR.format(i=i)
    body += EVT.format(i=i)

xml = HEADER + body + EMPTY
with open(LAYOUT, "w", encoding="utf-8") as f:
    f.write(xml)


def arr(name):
    ids = ", ".join(f"R.id.{name}{i}" for i in range(SLOTS))
    return f"    val {name} = intArrayOf({ids})"


kt = f'''package com.example.calwidget

/**
 * ID статичных слотов строк виджета (заголовок дня + строка события).
 * Файл и widget_layout.xml генерируются скриптом scripts/gen_widget_slots.py.
 */
internal object Slots {{
    const val COUNT = {SLOTS}
{chr(10).join(arr(n) for n in ("hdr", "evt", "dot", "time", "title", "loc"))}
}}
'''
with open(SLOTS_KT, "w", encoding="utf-8") as f:
    f.write(kt)

print(f"OK: {LAYOUT} ({len(xml)} байт), {SLOTS_KT} — {SLOTS} слотов")
