package com.example.ugolki.util

import android.content.Context
import com.example.ugolki.game.Game

/**
 * Настройки, статистика и автосохранение текущей партии (SharedPreferences).
 */
class Prefs(context: Context) {

    class SavedGame(
        val board: IntArray,
        val turn: Int,
        val lightMoves: Int,
        val darkMoves: Int,
        val pendingDraw: Boolean,
        val lastFrom: Int,
        val lastTo: Int
    )

    private val sp = context.getSharedPreferences("ugolki", Context.MODE_PRIVATE)

    var mode: Int
        get() = sp.getInt("mode", 0)
        set(v) { sp.edit().putInt("mode", v).apply() }

    var difficulty: Int
        get() = sp.getInt("difficulty", 1)
        set(v) { sp.edit().putInt("difficulty", v).apply() }

    var diagonals: Boolean
        get() = sp.getBoolean("diagonals", true)
        set(v) { sp.edit().putBoolean("diagonals", v).apply() }

    var wins: Int
        get() = sp.getInt("wins", 0)
        set(v) { sp.edit().putInt("wins", v).apply() }

    var losses: Int
        get() = sp.getInt("losses", 0)
        set(v) { sp.edit().putInt("losses", v).apply() }

    var draws: Int
        get() = sp.getInt("draws", 0)
        set(v) { sp.edit().putInt("draws", v).apply() }

    fun saveGame(game: Game, mode: Int) {
        val lm = game.lastMove
        sp.edit()
            .putString("board", game.board.joinToString(","))
            .putInt("turn", game.turn)
            .putInt("lm", game.lightMovesMade)
            .putInt("dm", game.darkMovesMade)
            .putBoolean("pending", game.pendingDraw)
            .putInt("lastf", lm?.from ?: -1)
            .putInt("lastt", lm?.to ?: -1)
            .putInt("mode", mode)
            .apply()
    }

    /** Восстановленная партия или null, если сохранения нет/повреждено. */
    fun loadGame(): SavedGame? {
        val s = sp.getString("board", null) ?: return null
        val parts = s.split(",")
        if (parts.size != Game.CELLS) return null
        val board = IntArray(Game.CELLS)
        var lights = 0
        var darks = 0
        for (i in parts.indices) {
            val v = parts[i].toIntOrNull() ?: return null
            if (v < Game.EMPTY || v > Game.DRAW) return null
            if (v == Game.LIGHT) lights++
            if (v == Game.DARK) darks++
            board[i] = v
        }
        if (lights != 16 || darks != 16) return null
        val turn = sp.getInt("turn", Game.LIGHT)
        if (turn != Game.LIGHT && turn != Game.DARK) return null
        return SavedGame(
            board, turn,
            sp.getInt("lm", 0), sp.getInt("dm", 0),
            sp.getBoolean("pending", false),
            sp.getInt("lastf", -1), sp.getInt("lastt", -1)
        )
    }

    fun clearSaved() {
        sp.edit()
            .remove("board").remove("turn").remove("lm").remove("dm")
            .remove("pending").remove("lastf").remove("lastt")
            .apply()
    }
}
