package com.example.ugolki.game

import kotlin.math.abs
import kotlin.random.Random

/**
 * Компьютерный соперник. Три уровня:
 *  - EASY:   почти случайные ходы (иногда жадные);
 *  - MEDIUM: жадная тактика с лёгким «шумом» (оценка на 1 ход вперёд);
 *  - HARD:   негамакс с альфа-бета отсечением, итеративное углубление до 4
 *            полуходов с бюджетом времени ~0,9 с (плавно на любом устройстве).
 */
object Ai {

    const val EASY = 0
    const val MEDIUM = 1
    const val HARD = 2

    private const val WIN_SCORE = 10000
    private val SEARCH_DIRS = arrayOf(
        intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1),
        intArrayOf(-1, -1), intArrayOf(-1, 1), intArrayOf(1, -1), intArrayOf(1, 1)
    )
    private val SEARCH_DIRS_STRAIGHT = arrayOf(
        intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1)
    )

    private class SearchTimeout : Exception()

    /** Выбирает ход для стороны, чья очередь в [game]. null — ходов нет. */
    fun chooseMove(game: Game, level: Int): Move? {
        val moves = game.movesOfSide(game.turn)
        if (moves.isEmpty()) return null
        return when (level) {
            EASY -> if (Random.nextDouble() < 0.25) greedy(moves, game, 0) else moves.random()
            MEDIUM -> greedy(moves, game, 14)
            else -> searchBest(moves, game)
        }
    }

    /** Оценка позиции для стороны [side]: прогресс к дому минус прогресс соперника. */
    fun evalBoard(board: IntArray, side: Int): Int {
        var s = 0
        for (cell in 0 until Game.CELLS) {
            val p = board[cell]
            if (p == Game.EMPTY) continue
            val r = cell / Game.SIZE
            val c = cell % Game.SIZE
            if (p == Game.LIGHT) {
                val d = blockDist(r, c, 0, 3, 4, 7)     // дом тёмных
                s -= 4 * d
                if (d == 0) s += 30 else if (r in 4..7 && c in 0..3) s -= 16
            } else {
                val d = blockDist(r, c, 4, 7, 0, 3)     // дом светлых
                s += 4 * d
                if (d == 0) s -= 30 else if (r in 0..3 && c in 4..7) s += 16
            }
        }
        return if (side == Game.LIGHT) s else -s
    }

    /** Расстояние Чебышёва до прямоугольного блока (0 — внутри блока). */
    private fun blockDist(r: Int, c: Int, r0: Int, r1: Int, c0: Int, c1: Int): Int {
        val rr = minOf(maxOf(r, r0), r1)
        val cc = minOf(maxOf(c, c0), c1)
        return maxOf(abs(r - rr), abs(c - cc))
    }

    /** Жадный выбор хода по позиции после хода (с шумом [noise]). */
    private fun greedy(moves: List<Move>, game: Game, noise: Int): Move {
        val board = game.board.copyOf()
        val side = game.turn
        var best = moves[0]
        var bestScore = Int.MIN_VALUE
        for (m in moves) {
            board[m.to] = side
            board[m.from] = Game.EMPTY
            var score = evalBoard(board, side)
            if (noise > 0) score += Random.nextInt(-noise, noise + 1)
            board[m.from] = side
            board[m.to] = Game.EMPTY
            if (score > bestScore) {
                bestScore = score
                best = m
            }
        }
        return best
    }

    /** Поиск лучшего хода: итеративное углубление с бюджетом времени. */
    private fun searchBest(moves: List<Move>, game: Game): Move {
        val board = game.board.copyOf()
        val side = game.turn
        val diagonals = game.diagonals
        val deadline = System.nanoTime() + 900_000_000L
        var best = greedy(moves, game, 0)
        for (depth in 2..4) {
            try {
                var localBest: Move? = null
                var localScore = Int.MIN_VALUE
                for (m in moves) {
                    board[m.to] = side
                    board[m.from] = Game.EMPTY
                    val score = if (hasWonBoard(board, side)) WIN_SCORE
                    else -negamax(board, Game.other(side), depth - 1, Int.MIN_VALUE + 1, Int.MAX_VALUE, 1, diagonals, deadline)
                    board[m.from] = side
                    board[m.to] = Game.EMPTY
                    if (score > localScore) {
                        localScore = score
                        localBest = m
                    }
                }
                if (localBest != null) best = localBest
            } catch (e: SearchTimeout) {
                break
            }
        }
        return best
    }

    private fun negamax(
        board: IntArray, side: Int, depth: Int,
        alphaIn: Int, beta: Int, ply: Int,
        diagonals: Boolean, deadline: Long
    ): Int {
        if (depth == 0) return evalBoard(board, side)
        val moves = genMoves(board, side, diagonals)
        if (moves.isEmpty()) return -WIN_SCORE + ply

        // упорядочивание ходов по жадной оценке (для эффективности отсечений)
        val scores = IntArray(moves.size)
        for (i in moves.indices) {
            val m = moves[i]
            board[m[1]] = side
            board[m[0]] = Game.EMPTY
            scores[i] = evalBoard(board, side)
            board[m[0]] = side
            board[m[1]] = Game.EMPTY
        }
        val order = moves.indices.sortedByDescending { scores[it] }

        var alpha = alphaIn
        var best = Int.MIN_VALUE + 1
        for (idx in order) {
            if (System.nanoTime() > deadline) throw SearchTimeout()
            val m = moves[idx]
            board[m[1]] = side
            board[m[0]] = Game.EMPTY
            val score = if (hasWonBoard(board, side)) WIN_SCORE - ply
            else -negamax(board, Game.other(side), depth - 1, -beta, -alpha, ply + 1, diagonals, deadline)
            board[m[0]] = side
            board[m[1]] = Game.EMPTY
            if (score > best) best = score
            if (best > alpha) alpha = best
            if (alpha >= beta) break
        }
        return best
    }

    /** Быстрая генерация ходов (from, to) для поиска — без путей. */
    private fun genMoves(board: IntArray, side: Int, diagonals: Boolean): ArrayList<IntArray> {
        val out = ArrayList<IntArray>(64)
        val directions = if (diagonals) SEARCH_DIRS else SEARCH_DIRS_STRAIGHT
        for (frm in 0 until Game.CELLS) {
            if (board[frm] != side) continue
            val r0 = frm / Game.SIZE
            val c0 = frm % Game.SIZE
            for (d in directions) {
                val r = r0 + d[0]
                val c = c0 + d[1]
                if (r in 0..7 && c in 0..7 && board[r * Game.SIZE + c] == Game.EMPTY) {
                    out.add(intArrayOf(frm, r * Game.SIZE + c))
                }
            }
            val came = IntArray(Game.CELLS) { -1 }
            val visited = BooleanArray(Game.CELLS)
            visited[frm] = true
            val queue = IntArray(Game.CELLS)
            var head = 0
            var tail = 0
            queue[tail++] = frm
            while (head < tail) {
                val cur = queue[head++]
                val cr = cur / Game.SIZE
                val cc = cur % Game.SIZE
                for (d in directions) {
                    val mr = cr + d[0]
                    val mc = cc + d[1]
                    val lr = cr + 2 * d[0]
                    val lc = cc + 2 * d[1]
                    if (mr < 0 || mr > 7 || mc < 0 || mc > 7) continue
                    if (lr < 0 || lr > 7 || lc < 0 || lc > 7) continue
                    val mid = mr * Game.SIZE + mc
                    val land = lr * Game.SIZE + lc
                    if (board[mid] != Game.EMPTY && board[land] == Game.EMPTY && !visited[land]) {
                        visited[land] = true
                        came[land] = cur
                        queue[tail++] = land
                    }
                }
            }
            for (i in 1 until tail) {
                out.add(intArrayOf(frm, queue[i]))
            }
        }
        return out
    }

    private fun hasWonBoard(board: IntArray, side: Int): Boolean {
        if (side == Game.LIGHT) {
            for (r in 0..3) {
                for (c in 4..7) {
                    if (board[r * Game.SIZE + c] != side) return false
                }
            }
        } else {
            for (r in 4..7) {
                for (c in 0..3) {
                    if (board[r * Game.SIZE + c] != side) return false
                }
            }
        }
        return true
    }
}
