package com.example.ugolki

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import com.example.ugolki.bt.BtGame
import com.example.ugolki.game.Ai
import com.example.ugolki.game.Game
import com.example.ugolki.game.Move
import com.example.ugolki.ui.BoardView
import com.example.ugolki.util.Prefs
import com.example.ugolki.util.Sfx

/**
 * Главный экран: партии против телефона, вдвоём на одном экране
 * и по Bluetooth, статистика, автосохранение, меню настроек.
 */
class MainActivity : Activity(), BoardView.Listener, BtGame.Listener {

    companion object {
        const val MODE_AI = 0
        const val MODE_HOTSEAT = 1
        const val MODE_BT = 2
        private const val REQ_BT = 41
    }

    private lateinit var game: Game
    private lateinit var board: BoardView
    private lateinit var statusView: TextView
    private lateinit var p1Name: TextView
    private lateinit var p1Sub: TextView
    private lateinit var p2Name: TextView
    private lateinit var p2Sub: TextView
    private lateinit var prefs: Prefs
    private lateinit var sfx: Sfx

    private var bt: BtGame? = null
    private var waitDialog: AlertDialog? = null
    private var statusToast: Toast? = null

    private var mode = MODE_AI
    private var mySide = Game.LIGHT   // своя сторона в Bluetooth
    private var busy = false          // анимация / ход ИИ / ход соперника
    private var pendingRemote: IntArray? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        sfx = Sfx()
        game = Game()

        board = findViewById(R.id.board) as BoardView
        statusView = findViewById(R.id.status) as TextView
        p1Name = findViewById(R.id.p1Name) as TextView
        p1Sub = findViewById(R.id.p1Sub) as TextView
        p2Name = findViewById(R.id.p2Name) as TextView
        p2Sub = findViewById(R.id.p2Sub) as TextView

        board.listener = this
        board.game = game

        val btnMenu = findViewById(R.id.btnMenu) as Button
        val btnNew = findViewById(R.id.btnNew) as Button
        btnMenu.setOnClickListener { showMenu(it) }
        btnNew.setOnClickListener { onNewGameClicked() }

        setupSession()
        updateUi()

        // восстановленная партия, где ход тёмных, — телефон продолжает думать
        if (mode == MODE_AI && game.winner == 0 && game.turn == Game.DARK) {
            thinkAndMove()
        }
    }

    // ---------------- Сессия и сохранение ----------------

    private fun setupSession() {
        mode = prefs.mode
        if (mode == MODE_BT) {
            // после перезапуска приложения Bluetooth-партию продолжить нельзя
            mode = MODE_AI
            prefs.mode = MODE_AI
            toast(getString(R.string.bt_session_lost))
        }
        game.diagonals = prefs.diagonals
        game.reset()

        val saved = prefs.loadGame()
        if (saved != null) {
            System.arraycopy(saved.board, 0, game.board, 0, Game.CELLS)
            game.turn = saved.turn
            game.lightMovesMade = saved.lightMoves
            game.darkMovesMade = saved.darkMoves
            game.pendingDraw = saved.pendingDraw
            game.lastMove = if (saved.lastFrom >= 0 && saved.lastTo >= 0) {
                Move(saved.lastFrom, saved.lastTo, intArrayOf(saved.lastFrom, saved.lastTo), false)
            } else {
                null
            }
            game.winner = 0
            game.winReason = Game.REASON_HOME
            if (game.lightMovesMade + game.darkMovesMade > 0) {
                toast(getString(R.string.game_restored))
            }
        }
    }

    private fun newGame() {
        game.reset()
        busy = false
        pendingRemote = null
        board.clearSelection()
        board.cancelAnimation()
        if (mode == MODE_BT) {
            bt?.sendNewGame()
        } else {
            prefs.clearSaved()
        }
        updateUi()
    }

    private fun onNewGameClicked() {
        if (game.winner == 0 && game.lightMovesMade + game.darkMovesMade > 0) {
            AlertDialog.Builder(this)
                .setTitle(R.string.confirm_title)
                .setMessage(R.string.confirm_new_game)
                .setPositiveButton(R.string.yes) { _, _ -> newGame() }
                .setNegativeButton(R.string.no, null)
                .show()
        } else {
            newGame()
        }
    }

    // ---------------- Ходы ----------------

    override fun onMoveMade(move: Move) {
        // ход человека с доски
        if (busy || game.winner != 0) return
        if (mode == MODE_HOTSEAT || game.turn == mySide || (mode == MODE_AI && game.turn == Game.LIGHT)) {
            performMove(move, remote = false)
        }
    }

    private fun performMove(move: Move, remote: Boolean) {
        if (game.winner != 0) return
        val mover = game.turn
        if (!game.apply(move.from, move.to)) return

        if (mode != MODE_BT) {
            prefs.saveGame(game, mode)
        }
        if (mode == MODE_BT && !remote) {
            bt?.sendMove(move.from, move.to)
        }
        sfx.move(move.isJump)
        busy = true
        board.clearSelection()
        board.animateMove(move) {
            busy = false
            afterMove(mover)
        }
    }

    private fun afterMove(mover: Int) {
        if (game.winner != 0) {
            onGameOver()
            updateUi()
            return
        }
        // предупреждение о правиле 40 ходов
        val ownMoves = if (mover == Game.LIGHT) game.lightMovesMade else game.darkMovesMade
        if (ownMoves in 35..40 && game.homePieces(mover) > 0) {
            toast(getString(R.string.warn_40, 41 - ownMoves))
        }
        // отложенный ход соперника по Bluetooth (пришёл во время анимации)
        pendingRemote?.let { arr ->
            pendingRemote = null
            applyRemote(arr[0], arr[1])
            return
        }
        if (mode == MODE_AI && game.turn == Game.DARK) {
            thinkAndMove()
        } else {
            updateUi()
        }
    }

    private fun thinkAndMove() {
        busy = true
        updateUi()
        val snapshot = game.copy()
        val level = prefs.difficulty
        Thread {
            val mv = Ai.chooseMove(snapshot, level)
            handler.post {
                if (mv != null && game.winner == 0 && game.turn == Game.DARK) {
                    val full = game.findMove(mv.from, mv.to)
                    if (full != null) {
                        performMove(full, remote = false)
                    } else {
                        busy = false
                        updateUi()
                    }
                } else {
                    busy = false
                    updateUi()
                }
            }
        }.start()
    }

    // ---------------- Конец партии ----------------

    private fun winnerTitle(): String {
        if (game.winner == 0) return ""
        if (game.winner == Game.DRAW) return getString(R.string.draw_title)
        return when (mode) {
            MODE_AI -> if (game.winner == Game.LIGHT) getString(R.string.you_win)
                      else getString(R.string.phone_wins)
            MODE_HOTSEAT -> if (game.winner == Game.LIGHT) getString(R.string.lights_win)
                            else getString(R.string.darks_win)
            else -> if (game.winner == mySide) getString(R.string.you_win)
                    else getString(R.string.opponent_wins)
        }
    }

    private fun onGameOver() {
        board.clearSelection()
        prefs.clearSaved()
        when (mode) {
            MODE_AI -> when (game.winner) {
                Game.LIGHT -> { prefs.wins++; sfx.win() }
                Game.DARK -> { prefs.losses++; sfx.lose() }
                else -> { prefs.draws++; sfx.draw() }
            }
            MODE_HOTSEAT -> if (game.winner == Game.DRAW) sfx.draw() else sfx.win()
            else -> when {
                game.winner == Game.DRAW -> sfx.draw()
                game.winner == mySide -> sfx.win()
                else -> sfx.lose()
            }
        }
        val reason = when (game.winReason) {
            Game.REASON_TIMEOUT_40 -> getString(R.string.reason_40)
            Game.REASON_NO_MOVES -> getString(R.string.reason_no_moves)
            else -> getString(R.string.reason_home)
        }
        var message = reason
        if (mode == MODE_AI) {
            message += "\n\n" + getString(R.string.score_line, prefs.wins, prefs.losses, prefs.draws)
        }
        AlertDialog.Builder(this)
            .setTitle(winnerTitle())
            .setMessage(message)
            .setPositiveButton(R.string.new_game) { _, _ -> newGame() }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    // ---------------- Меню и настройки ----------------

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, getString(R.string.mode_line, modeName()))
        pm.menu.add(0, 2, 1, getString(R.string.difficulty_line, difficultyName()))
        pm.menu.add(0, 3, 2, getString(R.string.diagonals_line, onOff()))
        pm.menu.add(0, 4, 3, getString(R.string.rules_line))
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> showModeDialog()
                2 -> showDifficultyDialog()
                3 -> showDiagonalsDialog()
                4 -> showRulesDialog()
            }
            true
        }
        pm.show()
    }

    private fun modeName(): String = when (mode) {
        MODE_HOTSEAT -> getString(R.string.mode_hotseat)
        MODE_BT -> getString(R.string.mode_bt)
        else -> getString(R.string.mode_ai)
    }

    private fun difficultyName(): String = when (prefs.difficulty) {
        Ai.EASY -> getString(R.string.diff_easy)
        Ai.HARD -> getString(R.string.diff_hard)
        else -> getString(R.string.diff_medium)
    }

    private fun onOff(): String = if (prefs.diagonals) getString(R.string.on) else getString(R.string.off)

    private fun showModeDialog() {
        val names = arrayOf(
            getString(R.string.mode_ai),
            getString(R.string.mode_hotseat),
            getString(R.string.mode_bt)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.mode_title)
            .setSingleChoiceItems(names, mode) { d, which ->
                d.dismiss()
                if (which == MODE_BT) {
                    startBtFlow()
                } else if (which != mode) {
                    switchLocalMode(which)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun switchLocalMode(newMode: Int) {
        stopBt()
        mode = newMode
        prefs.mode = newMode
        mySide = Game.LIGHT
        game.reset()
        busy = false
        pendingRemote = null
        board.clearSelection()
        board.cancelAnimation()
        prefs.clearSaved()
        toast(getString(R.string.mode_switched, modeName()))
        updateUi()
    }

    private fun showDifficultyDialog() {
        val names = arrayOf(
            getString(R.string.diff_easy_title),
            getString(R.string.diff_medium_title),
            getString(R.string.diff_hard_title)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.difficulty_title)
            .setSingleChoiceItems(names, prefs.difficulty) { d, which ->
                d.dismiss()
                prefs.difficulty = which
                toast(getString(R.string.difficulty_line, difficultyName()))
                updateUi()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showDiagonalsDialog() {
        val names = arrayOf(
            getString(R.string.diag_on_name),
            getString(R.string.diag_off_name)
        )
        val current = if (prefs.diagonals) 0 else 1
        AlertDialog.Builder(this)
            .setTitle(R.string.diagonals_title)
            .setSingleChoiceItems(names, current) { d, which ->
                d.dismiss()
                val value = which == 0
                if (value == prefs.diagonals) return@setSingleChoiceItems
                if (game.winner == 0 && game.lightMovesMade + game.darkMovesMade > 0) {
                    AlertDialog.Builder(this)
                        .setTitle(R.string.confirm_title)
                        .setMessage(R.string.confirm_diagonals)
                        .setPositiveButton(R.string.yes) { _, _ -> applyDiagonals(value) }
                        .setNegativeButton(R.string.no, null)
                        .show()
                } else {
                    applyDiagonals(value)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun applyDiagonals(value: Boolean) {
        prefs.diagonals = value
        game.diagonals = value
        game.reset()
        busy = false
        pendingRemote = null
        board.clearSelection()
        board.cancelAnimation()
        prefs.clearSaved()
        toast(getString(R.string.diagonals_changed, onOff()))
        updateUi()
    }

    private fun showRulesDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.rules_line)
            .setMessage(R.string.rules_text)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    // ---------------- Bluetooth ----------------

    private fun startBtFlow() {
        if (!BtGame.bluetoothAvailable(this)) {
            toast(getString(R.string.bt_unavailable))
            return
        }
        if (!BtGame.hasConnectPermission(this)) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQ_BT)
            return
        }
        showBtRoleDialog()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BT) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showBtRoleDialog()
            } else {
                toast(getString(R.string.bt_no_permission))
            }
        }
    }

    private fun showBtRoleDialog() {
        stopBt()
        bt = BtGame(this)
        val options = arrayOf(getString(R.string.bt_host), getString(R.string.bt_join))
        AlertDialog.Builder(this)
            .setTitle(R.string.bt_title)
            .setItems(options) { _, which ->
                if (which == 0) hostBt() else joinBt()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun hostBt() {
        bt?.startHost(this)
        showWaitDialog(
            getString(R.string.bt_waiting_title),
            getString(R.string.bt_waiting_msg)
        ) { stopBt() }
    }

    private fun joinBt() {
        val devices = bt?.pairedDevices(this) ?: emptyList()
        if (devices.isEmpty()) {
            toast(getString(R.string.bt_no_paired))
            stopBt()
            return
        }
        val names = devices.map { BtGame.safeName(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.bt_pick_device)
            .setItems(names) { _, which ->
                bt?.connectTo(this, devices[which])
                showWaitDialog(
                    getString(R.string.bt_connecting_title),
                    getString(R.string.bt_connecting_msg, names[which])
                ) { stopBt() }
            }
            .setNegativeButton(R.string.cancel) { _, _ -> stopBt() }
            .show()
    }

    private fun showWaitDialog(title: String, message: String, onCancel: () -> Unit) {
        hideWaitDialog()
        val d = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setNegativeButton(R.string.cancel) { _, _ -> onCancel() }
            .create()
        d.show()
        waitDialog = d
    }

    private fun hideWaitDialog() {
        waitDialog?.dismiss()
        waitDialog = null
    }

    private fun stopBt() {
        bt?.stop()
        bt = null
        board.flipped = false
        hideWaitDialog()
    }

    override fun onBtConnected(host: Boolean) {
        hideWaitDialog()
        mode = MODE_BT
        prefs.mode = mode
        mySide = if (host) Game.LIGHT else Game.DARK
        board.flipped = !host
        game.reset()
        busy = false
        pendingRemote = null
        board.clearSelection()
        toast(getString(R.string.bt_connected))
        if (host) {
            bt?.sendNewGame()
        }
        updateUi()
    }

    override fun onBtMove(from: Int, to: Int) {
        if (game.winner != 0) return
        if (busy) {
            pendingRemote = intArrayOf(from, to)
            return
        }
        applyRemote(from, to)
    }

    private fun applyRemote(from: Int, to: Int) {
        if (game.winner != 0) return
        val mv = game.findMove(from, to)
        if (mv == null || game.board[from] != game.turn) {
            // рассинхронизация: обе стороны перезапускают партию
            toast(getString(R.string.bt_desync))
            bt?.sendNewGame()
            game.reset()
            board.clearSelection()
            updateUi()
            return
        }
        performMove(mv, remote = true)
    }

    override fun onBtNewGame() {
        toast(getString(R.string.bt_opponent_new))
        game.reset()
        busy = false
        pendingRemote = null
        board.clearSelection()
        board.cancelAnimation()
        updateUi()
    }

    override fun onBtDisconnected(reason: String?) {
        hideWaitDialog()
        toast(reason ?: getString(R.string.bt_lost_title))
        stopBt()
        if (mode == MODE_BT) {
            board.cancelAnimation()
            busy = false
            AlertDialog.Builder(this)
                .setTitle(R.string.bt_lost_title)
                .setMessage(R.string.bt_lost_msg)
                .setPositiveButton(R.string.continue_vs_ai) { _, _ -> continueVsPhone() }
                .setNegativeButton(R.string.new_game) { _, _ -> switchLocalMode(MODE_AI) }
                .show()
        }
    }

    private fun continueVsPhone() {
        mode = MODE_AI
        prefs.mode = MODE_AI
        mySide = Game.LIGHT
        board.flipped = false
        busy = false
        updateUi()
        if (game.winner == 0 && game.turn == Game.DARK) {
            thinkAndMove()
        }
    }

    // ---------------- Отрисовка состояния ----------------

    private fun updateUi() {
        // карточки игроков
        when (mode) {
            MODE_AI -> {
                p1Name.text = getString(R.string.you)
                p2Name.text = getString(R.string.phone)
                p1Sub.text = getString(R.string.wins_n, prefs.wins)
                p2Sub.text = getString(R.string.difficulty_line, difficultyName()) +
                    " · " + getString(R.string.wins_n, prefs.losses)
            }
            MODE_HOTSEAT -> {
                p1Name.text = getString(R.string.lights)
                p2Name.text = getString(R.string.darks)
                p1Sub.text = getString(R.string.moves_first)
                p2Sub.text = getString(R.string.moves_second)
            }
            else -> {
                p1Name.text = getString(R.string.you)
                p2Name.text = getString(R.string.opponent)
                p1Sub.text = getString(R.string.your_color,
                    if (mySide == Game.LIGHT) getString(R.string.lights) else getString(R.string.darks))
                p2Sub.text = getString(R.string.bt_short)
            }
        }

        // статус
        statusView.text = if (game.winner != 0) {
            winnerTitle()
        } else {
            var s = when {
                mode == MODE_AI && game.turn == Game.DARK -> getString(R.string.thinking)
                mode == MODE_BT && game.turn != mySide -> getString(R.string.opponent_thinking)
                mode == MODE_HOTSEAT && game.turn == Game.DARK -> getString(R.string.darks_move)
                else -> getString(R.string.your_move)
            }
            s += " · " + getString(R.string.move_n, game.lightMovesMade + game.darkMovesMade + 1)
            if (game.pendingDraw) {
                s += "\n" + getString(R.string.pending_draw_hint)
            }
            s
        }

        // разрешение ходов
        val canPlay = game.winner == 0 && !busy
        val sideToMove = game.turn
        val allowed = when {
            !canPlay -> 0
            mode == MODE_AI -> if (sideToMove == Game.LIGHT) Game.LIGHT else 0
            mode == MODE_HOTSEAT -> sideToMove
            else -> if (sideToMove == mySide) mySide else 0
        }
        board.allowedSide = allowed
        board.interactive = allowed != 0
        board.invalidate()
    }

    private fun toast(text: String) {
        statusToast?.cancel()
        statusToast = Toast.makeText(this, text, Toast.LENGTH_SHORT)
        statusToast?.show()
    }

    // ---------------- Жизненный цикл ----------------

    override fun onResume() {
        super.onResume()
        sfx.resume()
        updateUi()
    }

    override fun onPause() {
        sfx.pause()
        super.onPause()
    }

    override fun onDestroy() {
        bt?.stop()
        bt = null
        super.onDestroy()
    }
}
