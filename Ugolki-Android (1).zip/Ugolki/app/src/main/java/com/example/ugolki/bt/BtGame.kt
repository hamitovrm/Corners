package com.example.ugolki.bt

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

/**
 * Матч по Bluetooth между двумя телефонами: один создаёт игру (сервер),
 * второй присоединяется из списка сопряжённых устройств.
 *
 * Протокол (строки UTF-8, разделитель — перевод строки):
 *   "M <from> <to>"  — ход соперника (клетки 0..63);
 *   "N"              — начать новую партию.
 *
 * Оба устройства держат одинаковое состояние и проверяют легальность
 * каждого полученного хода, поэтому «читерство» или потеря пакетов
 * приводят просто к перезапуску партии, а не к поломке игры.
 */
class BtGame(private val listener: Listener) {

    interface Listener {
        /** Соединение установлено; [host] == true, если это устройство создало игру. */
        fun onBtConnected(host: Boolean)

        /** Ход соперника (легальность должна проверить принимающая сторона). */
        fun onBtMove(from: Int, to: Int)

        /** Соперник начал новую партию. */
        fun onBtNewGame()

        /** Соединение закрыто или не удалось. [reason] — причина для сообщения. */
        fun onBtDisconnected(reason: String?)
    }

    companion object {
        val SERVICE_UUID: java.util.UUID =
            java.util.UUID.fromString("7d1a5d20-6c11-4b8e-9df1-3b6f2a9c0d84")
        const val SERVICE_NAME = "Ugolki"

        fun adapter(context: Context): BluetoothAdapter? {
            val manager =
                context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
                    ?: return null
            return manager.adapter
        }

        fun bluetoothAvailable(context: Context): Boolean = adapter(context) != null

        /** На Android 12+ требуется разрешение BLUETOOTH_CONNECT («Близлежащие устройства»). */
        fun hasConnectPermission(context: Context): Boolean =
            Build.VERSION.SDK_INT < 31 ||
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED

        // Разрешение проверяется вызывающей стороной перед использованием.
        @SuppressLint("MissingPermission")
        fun safeName(device: BluetoothDevice): String =
            try {
                device.name ?: device.address
            } catch (e: SecurityException) {
                device.address
            }

        // Разрешение проверяется перед вызовом (hasConnectPermission).
        @SuppressLint("MissingPermission")
        fun pairedDevices(context: Context): List<BluetoothDevice> {
            val a = adapter(context) ?: return emptyList()
            if (!hasConnectPermission(context)) return emptyList()
            return try {
                a.bondedDevices.toList()
            } catch (e: SecurityException) {
                emptyList()
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var acceptThread: AcceptThread? = null
    private var connectThread: ConnectThread? = null
    private var connectedThread: ConnectedThread? = null

    @Volatile
    private var running = false

    fun startHost(context: Context) {
        stop()
        val a = adapter(context) ?: run {
            postDisconnect("Bluetooth недоступен на этом устройстве")
            return
        }
        if (!hasConnectPermission(context)) {
            postDisconnect("Нет разрешения на использование Bluetooth")
            return
        }
        running = true
        acceptThread = AcceptThread(a).also { it.start() }
    }

    fun connectTo(context: Context, device: BluetoothDevice) {
        stop()
        if (!hasConnectPermission(context)) {
            postDisconnect("Нет разрешения на использование Bluetooth")
            return
        }
        running = true
        connectThread = ConnectThread(device).also { it.start() }
    }

    @Synchronized
    fun stop() {
        running = false
        acceptThread?.cancel()
        acceptThread = null
        connectThread?.cancel()
        connectThread = null
        connectedThread?.cancel()
        connectedThread = null
    }

    fun sendMove(from: Int, to: Int) {
        write("M $from $to")
    }

    fun sendNewGame() {
        write("N")
    }

    private fun write(line: String) {
        connectedThread?.write((line + "\n").toByteArray(Charsets.UTF_8))
    }

    @Synchronized
    private fun connected(socket: BluetoothSocket, host: Boolean) {
        connectedThread = ConnectedThread(socket).also { it.start() }
        handler.post { listener.onBtConnected(host) }
    }

    private fun onLine(line: String) {
        val t = line.trim()
        handler.post {
            when {
                t.startsWith("M") -> {
                    val parts = t.split(" ")
                    if (parts.size == 3) {
                        val from = parts[1].toIntOrNull()
                        val to = parts[2].toIntOrNull()
                        if (from != null && to != null) {
                            listener.onBtMove(from, to)
                        }
                    }
                }
                t == "N" -> listener.onBtNewGame()
            }
        }
    }

    private fun postDisconnect(reason: String) {
        handler.post {
            if (running) {
                running = false
                listener.onBtDisconnected(reason)
            }
        }
    }

    // Разрешение BLUETOOTH_CONNECT проверяется в startHost перед запуском.
    @SuppressLint("MissingPermission")
    private inner class AcceptThread(private val adapter: BluetoothAdapter) : Thread() {
        private var server: BluetoothServerSocket? = null

        init {
            try {
                server = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SERVICE_UUID)
            } catch (e: IOException) {
                server = null
            }
        }

        override fun run() {
            val s = server
            if (s == null) {
                postDisconnect("Не удалось открыть игру по Bluetooth")
                return
            }
            var accepted: BluetoothSocket? = null
            try {
                accepted = s.accept()   // блокируется до подключения соперника
            } catch (e: IOException) {
                // сервер закрыт (stop) — просто выходим
            }
            try {
                s.close()
            } catch (ignored: IOException) {
            }
            if (accepted != null && running) {
                connected(accepted, host = true)
            } else {
                try {
                    accepted?.close()
                } catch (ignored: IOException) {
                }
            }
        }

        fun cancel() {
            try {
                server?.close()
            } catch (ignored: IOException) {
            }
        }
    }

    // Разрешение BLUETOOTH_CONNECT проверяется в connectTo перед запуском.
    @SuppressLint("MissingPermission")
    private inner class ConnectThread(private val device: BluetoothDevice) : Thread() {
        private var socket: BluetoothSocket? = null

        override fun run() {
            val sock: BluetoothSocket
            try {
                sock = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
            } catch (e: IOException) {
                postDisconnect("Не удалось создать соединение")
                return
            }
            socket = sock
            try {
                sock.connect()
            } catch (e: IOException) {
                try {
                    sock.close()
                } catch (ignored: IOException) {
                }
                postDisconnect("Не удалось подключиться. Телефон друга рядом, в «Уголках» выбрано «Создать игру»?")
                return
            }
            if (running) {
                connected(sock, host = false)
            } else {
                try {
                    sock.close()
                } catch (ignored: IOException) {
                }
            }
        }

        fun cancel() {
            try {
                socket?.close()
            } catch (ignored: IOException) {
            }
        }
    }

    private inner class ConnectedThread(private val socket: BluetoothSocket) : Thread() {
        private val out = socket.outputStream

        override fun run() {
            var line: String?
            try {
                val reader = BufferedReader(InputStreamReader(socket.inputStream, Charsets.UTF_8))
                while (running) {
                    line = reader.readLine()
                    if (line == null) break
                    if (line.isNotBlank()) onLine(line)
                }
            } catch (e: IOException) {
                // сокет закрыт
            }
            if (running) {
                postDisconnect("Соединение потеряно")
            }
        }

        fun write(bytes: ByteArray) {
            try {
                out.write(bytes)
                out.flush()
            } catch (e: IOException) {
                postDisconnect("Соединение потеряно")
            }
        }

        fun cancel() {
            try {
                socket.close()
            } catch (ignored: IOException) {
            }
        }
    }
}
