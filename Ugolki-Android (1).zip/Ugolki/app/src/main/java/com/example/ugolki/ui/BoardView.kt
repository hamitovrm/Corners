package com.example.ugolki.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.ugolki.game.Game
import com.example.ugolki.game.Move
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Деревянная доска: отрисовка, выбор шашек, подсветка допустимых ходов
 * и плавная анимация перемещения (прыжки «перелетают» дугой).
 */
class BoardView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    interface Listener {
        fun onMoveMade(move: Move)
    }

    var game: Game? = null
    /** Ориентация «от себя» (для клиента Bluetooth, играющего тёмными). */
    var flipped = false
    /** Каким цветом разрешено ходить (0 — ходить нельзя). */
    var allowedSide = 0
    var interactive = false
    var listener: Listener? = null

    private var selected = -1
    private var hints: List<Move> = emptyList()
    private var cell = 0f

    private var animMove: Move? = null
    private var animProgress = 0f
    private var animDone: (() -> Unit)? = null
    private var animator: ValueAnimator? = null

    private val squareLight = Paint()
    private val squareDark = Paint()
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val homeLightPaint = Paint(Paint.ANTI_ALIAS_FLAG) // контур цели светлых
    private val homeDarkPaint = Paint(Paint.ANTI_ALIAS_FLAG)   // контур цели тёмных
    private val lastMovePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        squareLight.color = 0xFFF0D9A8.toInt()
        squareDark.color = 0xFFC89B62.toInt()
        borderPaint.color = 0xFF6D4C41.toInt()
        borderPaint.style = Paint.Style.STROKE
        homeLightPaint.color = 0x66FFF3E0.toInt()
        homeLightPaint.style = Paint.Style.STROKE
        homeDarkPaint.color = 0x663E2723.toInt()
        homeDarkPaint.style = Paint.Style.STROKE
        lastMovePaint.color = 0x38FFC107.toInt()
        hintPaint.color = 0x905D4037.toInt()
        selectPaint.color = 0xFFFFC107.toInt()
        selectPaint.style = Paint.Style.STROKE
        shadowPaint.color = 0x3D000000.toInt()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val s = min(w, h)
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cell = w / Game.SIZE.toFloat()
        borderPaint.strokeWidth = cell * 0.05f
        selectPaint.strokeWidth = cell * 0.06f
        homeLightPaint.strokeWidth = cell * 0.045f
        homeDarkPaint.strokeWidth = cell * 0.045f
    }

    private fun dispRow(idx: Int): Int {
        val r = idx / Game.SIZE
        return if (flipped) 7 - r else r
    }

    private fun dispCol(idx: Int): Int {
        val c = idx % Game.SIZE
        return if (flipped) 7 - c else c
    }

    private fun cx(idx: Int): Float = dispCol(idx) * cell + cell / 2f
    private fun cy(idx: Int): Float = dispRow(idx) * cell + cell / 2f

    private fun cellRect(idx: Int): RectF =
        RectF(dispCol(idx) * cell, dispRow(idx) * cell,
              (dispCol(idx) + 1) * cell, (dispRow(idx) + 1) * cell)

    override fun onDraw(canvas: Canvas) {
        val g = game ?: return
        val w = width.toFloat()

        // клетки «дерева» двух тонов
        for (r in 0..7) {
            for (c in 0..7) {
                val p = if ((r + c) % 2 == 0) squareLight else squareDark
                canvas.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p)
            }
        }

        // контуры домов: светлые стремятся в верхний правый, тёмные — в нижний левый
        drawHomeOutline(canvas, g.homeDark, homeLightPaint)
        drawHomeOutline(canvas, g.homeLight, homeDarkPaint)

        // подсветка последнего хода
        g.lastMove?.let { lm ->
            canvas.drawRect(cellRect(lm.from), lastMovePaint)
            canvas.drawRect(cellRect(lm.to), lastMovePaint)
        }

        // рамка доски
        val half = borderPaint.strokeWidth * 0.5f
        canvas.drawRect(half, half, w - half, w - half, borderPaint)

        // подсказки: точки на допустимых клетках
        if (selected >= 0) {
            for (m in hints) {
                canvas.drawCircle(cx(m.to), cy(m.to), cell * 0.15f, hintPaint)
            }
        }

        // шашки (кроме той, что сейчас анимируется)
        val animatingTo = animMove?.to ?: -1
        for (idx in 0 until Game.CELLS) {
            val p = g.board[idx]
            if (p == Game.EMPTY || idx == animatingTo) continue
            drawPiece(canvas, cx(idx), cy(idx), p)
        }

        // выделение выбранной шашки
        if (selected >= 0 && g.board[selected] == allowedSide) {
            canvas.drawCircle(cx(selected), cy(selected), cell * 0.44f, selectPaint)
        }

        // анимируемая шашка
        animMove?.let { mv ->
            val side = g.board[mv.to]
            val pos = animPosition(mv)
            drawPiece(canvas, pos.first, pos.second, side)
        }
    }

    private fun drawHomeOutline(canvas: Canvas, home: IntArray, paint: Paint) {
        var minR = 7; var maxR = 0; var minC = 7; var maxC = 0
        for (i in home.indices) {
            val r = dispRow(home[i])
            val c = dispCol(home[i])
            if (r < minR) minR = r
            if (r > maxR) maxR = r
            if (c < minC) minC = c
            if (c > maxC) maxC = c
        }
        val inset = cell * 0.07f
        val rect = RectF(minC * cell + inset, minR * cell + inset,
            (maxC + 1) * cell - inset, (maxR + 1) * cell - inset)
        canvas.drawRoundRect(rect, cell * 0.25f, cell * 0.25f, paint)
    }

    private fun drawPiece(canvas: Canvas, x: Float, y: Float, side: Int) {
        val r = cell * 0.38f
        // мягкая тень
        canvas.drawCircle(x + cell * 0.02f, y + cell * 0.04f, r, shadowPaint)
        // корпус с радиальным градиентом
        val hi: Int
        val base: Int
        if (side == Game.LIGHT) {
            hi = 0xFFFFFCF2.toInt()
            base = 0xFFE7D3AC.toInt()
        } else {
            hi = 0xFF7A5A46.toInt()
            base = 0xFF46302A.toInt()
        }
        piecePaint.shader = RadialGradient(x - r * 0.35f, y - r * 0.4f, r * 1.8f, hi, base, Shader.TileMode.CLAMP)
        canvas.drawCircle(x, y, r, piecePaint)
        piecePaint.shader = null
        // ободок
        rimPaint.style = Paint.Style.STROKE
        rimPaint.strokeWidth = r * 0.13f
        rimPaint.color = if (side == Game.LIGHT) 0xFFC2A570.toInt() else 0xFF281913.toInt()
        canvas.drawCircle(x, y, r * 0.94f, rimPaint)
        // блик
        shinePaint.color = if (side == Game.LIGHT) 0x8CFFFFFF.toInt() else 0x38FFFFFF.toInt()
        canvas.drawOval(RectF(x - r * 0.55f, y - r * 0.62f, x + r * 0.25f, y - r * 0.2f), shinePaint)
    }

    /** Позиция анимируемой шашки вдоль пути (прыжки — с подъёмом по дуге). */
    private fun animPosition(mv: Move): Pair<Float, Float> {
        val pts = mv.path
        val n = pts.size - 1
        val t = animProgress.coerceIn(0f, 1f)
        val seg = minOf((t * n).toInt(), n - 1)
        val local = t * n - seg
        val ax = cx(pts[seg])
        val ay = cy(pts[seg])
        val bx = cx(pts[seg + 1])
        val by = cy(pts[seg + 1])
        val lift = if (mv.isJump) sin((PI * local).toFloat()) * cell * 0.22f else 0f
        return Pair(ax + (bx - ax) * local, ay + (by - ay) * local - lift)
    }

    /** Запускает анимацию хода; [onDone] вызывается по завершении. */
    fun animateMove(move: Move, onDone: (() -> Unit)?) {
        cancelAnimator()
        animMove = move
        animProgress = 0f
        animDone = onDone
        val duration = if (move.isJump) 170L * (move.path.size - 1) else 230L
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = duration
        a.addUpdateListener { anim -> animProgress = anim.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animMove = null
                animProgress = 1f
                invalidate()
                val cb = animDone
                animDone = null
                cb?.invoke()
            }
        })
        animator = a
        a.start()
    }

    private fun cancelAnimator() {
        animDone = null
        animator?.cancel()
        animator = null
        animMove = null
        animProgress = 1f
    }

    fun cancelAnimation() {
        cancelAnimator()
        invalidate()
    }

    fun clearSelection() {
        selected = -1
        hints = emptyList()
        invalidate()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN) return true
        if (!interactive) return true
        val g = game ?: return true
        if (g.winner != 0) return true
        val col = (event.x / cell).toInt().coerceIn(0, 7)
        val row = (event.y / cell).toInt().coerceIn(0, 7)
        val idx = if (flipped) (7 - row) * Game.SIZE + (7 - col) else row * Game.SIZE + col

        // ход на подсвеченную клетку
        if (selected >= 0) {
            val mv = hints.firstOrNull { it.to == idx }
            if (mv != null) {
                clearSelection()
                listener?.onMoveMade(mv)
                return true
            }
        }
        // выбор своей шашки
        if (g.board[idx] == allowedSide) {
            selected = idx
            hints = g.legalMovesFrom(idx)
        } else {
            selected = -1
            hints = emptyList()
        }
        invalidate()
        return true
    }
}
