package com.example.ugolki.game

/**
 * Ход: откуда (from), куда (to) и полный путь для анимации.
 * Клетка кодируется как row * 8 + col (0..63), строка 0 — верхняя.
 */
class Move(val from: Int, val to: Int, val path: IntArray, val isJump: Boolean)

/**
 * Полное состояние партии «Уголки» (16 шашек у каждого, дома 4x4).
 *
 * Правила (классический бытовой вариант, см. README):
 *  - доска 8x8; светлые (LIGHT) стоят в нижнем левом углу (rows 4..7, cols 0..3),
 *    тёмные (DARK) — в верхнем правом (rows 0..3, cols 4..7); ходят светлые первые;
 *  - за ход перемещается одна шашка: на соседнюю пустую клетку либо прыжком
 *    через одну шашку (любого цвета) на пустую клетку за ней; прыжки образуют цепочки;
 *  - цель — первым занять все 16 клеток дома соперника;
 *  - если тёмные завершают перенос своим ответным ходом — ничья;
 *  - если после 41-го своего хода у игрока остались шашки в собственном доме — поражение;
 *  - у игрока нет ходов — поражение.
 */
class Game {

    companion object {
        const val SIZE = 8
        const val CELLS = SIZE * SIZE
        const val EMPTY = 0
        const val LIGHT = 1
        const val DARK = 2
        const val DRAW = 3

        // причины окончания партии
        const val REASON_HOME = 0
        const val REASON_TIMEOUT_40 = 1
        const val REASON_NO_MOVES = 2

        private val DIRS_ALL = arrayOf(
            intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1),
            intArrayOf(-1, -1), intArrayOf(-1, 1), intArrayOf(1, -1), intArrayOf(1, 1)
        )
        private val DIRS_STRAIGHT = arrayOf(
            intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1)
        )

        fun other(side: Int): Int = if (side == LIGHT) DARK else LIGHT
    }

    val board = IntArray(CELLS)
    val homeLight = IntArray(16)
    val homeDark = IntArray(16)

    var turn = LIGHT
    var lightMovesMade = 0
    var darkMovesMade = 0
    var lastMove: Move? = null
    var winner = 0            // 0 — партия идёт, иначе LIGHT / DARK / DRAW
    var winReason = REASON_HOME
    var pendingDraw = false   // светлые заняли дом, тёмным даётся ответный ход
    var diagonals = true      // true: ходы и прыжки по 8 направлениям; false: только по прямым

    init {
        for (i in 0..15) {
            // дом светлых: строки 4..7, столбцы 0..3 (клетка = row * 8 + col)
            homeLight[i] = (i / 4 + 4) * SIZE + i % 4
            // дом тёмных: строки 0..3, столбцы 4..7
            homeDark[i] = i % 4 + 4 + (i / 4) * SIZE
        }
        reset()
    }

    fun reset() {
        java.util.Arrays.fill(board, EMPTY)
        for (i in 0..15) {
            board[homeLight[i]] = LIGHT
            board[homeDark[i]] = DARK
        }
        turn = LIGHT
        lightMovesMade = 0
        darkMovesMade = 0
        lastMove = null
        winner = 0
        winReason = REASON_HOME
        pendingDraw = false
    }

    fun copy(): Game {
        val g = Game()
        System.arraycopy(board, 0, g.board, 0, CELLS)
        g.turn = turn
        g.lightMovesMade = lightMovesMade
        g.darkMovesMade = darkMovesMade
        g.lastMove = lastMove
        g.winner = winner
        g.winReason = winReason
        g.pendingDraw = pendingDraw
        g.diagonals = diagonals
        return g
    }

    private fun dirs(): Array<IntArray> = if (diagonals) DIRS_ALL else DIRS_STRAIGHT

    /** Все легальные ходы шашки, стоящей на клетке [frm]. */
    fun legalMovesFrom(frm: Int): List<Move> {
        val side = board[frm]
        if (side == EMPTY) return emptyList()
        val r0 = frm / SIZE
        val c0 = frm % SIZE
        val result = ArrayList<Move>(20)
        val directions = dirs()

        // обычные шаги на соседнюю пустую клетку
        for (d in directions) {
            val r = r0 + d[0]
            val c = c0 + d[1]
            if (r in 0..7 && c in 0..7 && board[r * SIZE + c] == EMPTY) {
                val to = r * SIZE + c
                result.add(Move(frm, to, intArrayOf(frm, to), false))
            }
        }

        // прыжки: поиск в ширину по клеткам приземления
        val came = IntArray(CELLS) { -1 }
        val visited = BooleanArray(CELLS)
        visited[frm] = true
        val queue = IntArray(CELLS)
        var head = 0
        var tail = 0
        queue[tail++] = frm
        while (head < tail) {
            val cur = queue[head++]
            val cr = cur / SIZE
            val cc = cur % SIZE
            for (d in directions) {
                val mr = cr + d[0]
                val mc = cc + d[1]
                val lr = cr + 2 * d[0]
                val lc = cc + 2 * d[1]
                if (mr < 0 || mr > 7 || mc < 0 || mc > 7) continue
                if (lr < 0 || lr > 7 || lc < 0 || lc > 7) continue
                val mid = mr * SIZE + mc
                val land = lr * SIZE + lc
                if (board[mid] != EMPTY && board[land] == EMPTY && !visited[land]) {
                    visited[land] = true
                    came[land] = cur
                    queue[tail++] = land
                }
            }
        }
        for (i in 1 until tail) {
            val land = queue[i]
            val path = ArrayList<Int>(8)
            var cur = land
            while (cur != -1) {
                path.add(cur)
                cur = came[cur]
            }
            path.reverse()
            result.add(Move(frm, land, path.toIntArray(), true))
        }
        return result
    }

    /** Все ходы стороны [side]. */
    fun movesOfSide(side: Int): List<Move> {
        val moves = ArrayList<Move>(64)
        for (cell in 0 until CELLS) {
            if (board[cell] == side) {
                moves.addAll(legalMovesFrom(cell))
            }
        }
        return moves
    }

    fun isLegal(from: Int, to: Int): Boolean = findMove(from, to) != null

    /** Легальный ход из [from] в [to] (с полным путём для анимации) или null. */
    fun findMove(from: Int, to: Int): Move? =
        legalMovesFrom(from).firstOrNull { it.to == to }

    /** Все ли клетки целевого дома [side] заняты её шашками. */
    fun hasWon(side: Int): Boolean {
        val target = if (side == LIGHT) homeDark else homeLight
        for (cell in target) {
            if (board[cell] != side) return false
        }
        return true
    }

    /** Сколько шашек [side] осталось в собственном доме. */
    fun homePieces(side: Int): Int {
        val home = if (side == LIGHT) homeLight else homeDark
        var count = 0
        for (cell in home) {
            if (board[cell] == side) count++
        }
        return count
    }

    /** Есть ли у [side] хотя бы один допустимый ход. */
    fun hasMoves(side: Int): Boolean {
        for (cell in 0 until CELLS) {
            if (board[cell] == side && legalMovesFrom(cell).isNotEmpty()) return true
        }
        return false
    }

    /**
     * Применяет ход из [from] в [to] за текущую сторону: проверяет легальность,
     * переставляет шашку, обновляет счётчики ходов и определяет исход партии.
     * Возвращает true, если ход был применён.
     */
    fun apply(from: Int, to: Int): Boolean {
        if (winner != 0) return false
        if (board[from] != turn) return false
        val full = findMove(from, to) ?: return false

        val mover = turn
        board[to] = mover
        board[from] = EMPTY
        lastMove = full
        if (mover == LIGHT) lightMovesMade++ else darkMovesMade++

        val finished = hasWon(mover)
        val ownHome = homePieces(mover) > 0
        val ownMoves = if (mover == LIGHT) lightMovesMade else darkMovesMade

        if (ownHome && ownMoves > 40) {
            // правило 40 ходов: шашки не выведены из собственного дома
            winner = other(mover)
            winReason = REASON_TIMEOUT_40
        } else if (pendingDraw && mover == DARK) {
            // ответный ход тёмных после финиша светлых
            winner = if (finished) DRAW else LIGHT
            winReason = REASON_HOME
            pendingDraw = false
        } else if (finished) {
            if (mover == LIGHT) {
                pendingDraw = true   // тёмные могут сравняться последним ходом
            } else {
                winner = DARK
                winReason = REASON_HOME
            }
        }
        if (winner == 0) {
            turn = other(mover)
            if (!hasMoves(turn)) {
                winner = other(turn)
                winReason = REASON_NO_MOVES
            }
        }
        return true
    }
}
