package com.example.ugolki.util

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/**
 * Звуковые эффекты без внешних аудиофайлов — через системный ToneGenerator.
 * Ходы, прыжки, победа, поражение и ничья.
 */
class Sfx {

    private var tone: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())

    fun resume() {
        if (tone == null) {
            try {
                tone = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            } catch (e: RuntimeException) {
                tone = null
            }
        }
    }

    fun pause() {
        handler.removeCallbacksAndMessages(null)
        tone?.release()
        tone = null
    }

    private fun beep(toneType: Int, ms: Int, delayMs: Long = 0) {
        handler.postDelayed({
            try {
                tone?.startTone(toneType, ms)
            } catch (ignored: RuntimeException) {
            }
        }, delayMs)
    }

    fun move(isJump: Boolean) {
        if (isJump) {
            beep(ToneGenerator.TONE_PROP_BEEP2, 120)
        } else {
            beep(ToneGenerator.TONE_PROP_BEEP, 90)
        }
    }

    fun win() {
        beep(ToneGenerator.TONE_PROP_BEEP, 120, 0)
        beep(ToneGenerator.TONE_PROP_BEEP2, 120, 170)
        beep(ToneGenerator.TONE_PROP_ACK, 260, 360)
    }

    fun lose() {
        beep(ToneGenerator.TONE_PROP_NACK, 340, 0)
        beep(ToneGenerator.TONE_PROP_NACK, 300, 420)
    }

    fun draw() {
        beep(ToneGenerator.TONE_PROP_PROMPT, 220, 0)
    }
}
